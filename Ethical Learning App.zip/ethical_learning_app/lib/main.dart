import 'package:flutter/material.dart';

void main() {
  runApp(EthicalQuestApp());
}

class EthicalQuestApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ethical Quest',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.black,  // Set the scaffold background color to dark
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Ethical Quest',
          style: TextStyle(
            color: Colors.white,  // White text for better visibility
            fontSize: 24,  // Larger font size for visibility
          ),
        ),
        backgroundColor: Colors.black,  // Dark app bar to match theme
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/toys_background.jpg'), // Background image with toys
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.5), BlendMode.darken), // Darken the background
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Welcome to Ethical Quest! This app helps you learn about ethical decision-making through fun quizzes. Test your knowledge, track your progress, and climb the leaderboard!',
                  style: TextStyle(fontSize: 18, color: Colors.white),  // White text for visibility
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    IconButton(
                      icon: Icon(Icons.quiz, size: 50, color: Colors.white),  // White icon for visibility
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => NamePromptPage(forProgress: false)),
                        );
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.leaderboard, size: 50, color: Colors.greenAccent),  // Light green icon for leaderboard
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => Leaderboard(name: 'Guest', score: 0, totalQuizzes: 10),
                          ),
                        );
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.trending_up, size: 50, color: Colors.purpleAccent), // Light purple icon for progress tracking
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ProgressTrackingDashboard()),
                        );
                      },
                    ),
                  ],
                ),
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text('Quizzes', style: TextStyle(fontSize: 16, color: Colors.white)),  // White text
                    Text('Leaderboard', style: TextStyle(fontSize: 16, color: Colors.greenAccent)),  // Green accent text
                    Text('Progress', style: TextStyle(fontSize: 16, color: Colors.purpleAccent)), // Purple accent text
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class NamePromptPage extends StatelessWidget {
  final bool forProgress;

  NamePromptPage({required this.forProgress});

  @override
  Widget build(BuildContext context) {
    final TextEditingController nameController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: Text(forProgress ? 'Track Progress' : 'Enter Name'),
        backgroundColor: Colors.black,  // Dark app bar
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                labelText: 'Enter your name',
                border: OutlineInputBorder(),
                labelStyle: TextStyle(color: Colors.white),  // Light label text
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white),  // White border when focused
                ),
              ),
              style: TextStyle(color: Colors.white),  // White text in input field
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                String name = nameController.text;
                if (name.isNotEmpty) {
                  if (forProgress) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ProgressPage(name: name)),
                    );
                  } else {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => QuizModule(name: name)),
                    );
                  }
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
              child: Text('Submit'),
            ),
          ],
        ),
      ),
    );
  }
}

class ProgressPage extends StatelessWidget {
  final String name;

  ProgressPage({required this.name});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Progress Tracker'), backgroundColor: Colors.black),
      body: Center(
        child: Text('Tracking progress for: $name',
            style: TextStyle(fontSize: 18, color: Colors.white)),
      ),
    );
  }
}

class ProgressTrackingDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Progress Tracking Dashboard'), backgroundColor: Colors.black),
      body: Center(
        child: Text(
          'Here you can track your progress in completing the quizzes!',
          style: TextStyle(fontSize: 18, color: Colors.white),
        ),
      ),
    );
  }
}

class QuizModule extends StatelessWidget {
  final String name;

  QuizModule({required this.name});

  final List<Map<String, dynamic>> quizzes = [
    {
      'title': 'Quiz 1',
      'questions': [
        {'question': 'Do you think kindness is important in daily life?', 'answer': 'Yes'},
        {'question': 'Is it acceptable to cheat if nobody finds out?', 'answer': 'No'},
        {'question': 'Should you always take responsibility for your actions?', 'answer': 'Yes'},
      ],
    },
    {
      'title': 'Quiz 2',
      'questions': [
        {'question': 'Would you help a friend in need, even if it’s inconvenient for you?', 'answer': 'Yes'},
        {'question': 'Is it okay to break a promise if it’s for a good reason?', 'answer': 'No'},
        {'question': 'Do you think it’s wrong to take credit for someone else’s work?', 'answer': 'Yes'},
      ],
    },
    {
      'title': 'Quiz 3',
      'questions': [
        {'question': 'Would you report a friend if they were cheating in class?', 'answer': 'Yes'},
        {'question': 'Is it okay to take shortcuts if it results in success?', 'answer': 'No'},
        {'question': 'Do you think honesty is always the best policy?', 'answer': 'Yes'},
      ],
    },
    {
      'title': 'Quiz 4',
      'questions': [
        {'question': 'Should you always speak up against injustice, even if it’s uncomfortable?', 'answer': 'Yes'},
        {'question': 'Is it ethical to lie to protect someone\'s feelings?', 'answer': 'No'},
        {'question': 'Would you help someone who is being bullied, even if it’s risky?', 'answer': 'Yes'},
      ],
    },
    {
      'title': 'Quiz 5',
      'questions': [
        {'question': 'Is it wrong to plagiarize when you are under time pressure?', 'answer': 'No'},
        {'question': 'Should you always share your resources with those in need?', 'answer': 'Yes'},
        {'question': 'Is it acceptable to break the rules if the situation calls for it?', 'answer': 'No'},
      ],
    },
    {
      'title': 'Quiz 6',
      'questions': [
        {'question': 'Is it ethical to use someone else\'s work without permission?', 'answer': 'No'},
        {'question': 'Would you report a mistake that benefits you financially?', 'answer': 'Yes'},
        {'question': 'Is it okay to deceive others for their own good?', 'answer': 'No'},
      ],
    },
    {
      'title': 'Quiz 7',
      'questions': [
        {'question': 'Would you intervene if you saw someone being discriminated against?', 'answer': 'Yes'},
        {'question': 'Is it acceptable to break a promise to help a friend?', 'answer': 'No'},
        {'question': 'Should you always do what is right, even if others don’t?', 'answer': 'Yes'},
      ],
    },
    {
      'title': 'Quiz 8',
      'questions': [
        {'question': 'Would you act ethically, even if it meant losing something important to you?', 'answer': 'Yes'},
        {'question': 'Is it wrong to keep a secret that could harm someone?', 'answer': 'Yes'},
        {'question': 'Is it okay to act selfishly if you are the only one who will be affected?', 'answer': 'No'},
      ],
    },
    {
      'title': 'Quiz 9',
      'questions': [
        {'question': 'Should you always tell the truth, even if it might hurt someone?', 'answer': 'Yes'},
        {'question': 'Is it acceptable to lie for personal gain?', 'answer': 'No'},
        {'question': 'Would you act with integrity if no one was watching?', 'answer': 'Yes'},
      ],
    },
    {
      'title': 'Quiz 10',
      'questions': [
        {'question': 'Is it ethical to take credit for someone else\'s hard work?', 'answer': 'No'},
        {'question': 'Would you refuse to do something unethical even if pressured by peers?', 'answer': 'Yes'},
        {'question': 'Do you think it’s important to maintain a sense of responsibility?', 'answer': 'Yes'},
      ],
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Quiz Module'), backgroundColor: Colors.black),
      body: ListView.builder(
        itemCount: quizzes.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(quizzes[index]['title'], style: TextStyle(color: Colors.white)),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => QuizPage(quiz: quizzes[index], name: name, totalQuizzes: quizzes.length),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  final Map<String, dynamic> quiz;
  final String name;
  final int totalQuizzes;

  QuizPage({required this.quiz, required this.name, required this.totalQuizzes});

  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  final Map<int, String> _answers = {};
  int _score = 0;

  void _submitQuiz() {
    setState(() {
      _score = 0;
      for (int i = 0; i < widget.quiz['questions'].length; i++) {
        if (_answers[i]?.toLowerCase() == widget.quiz['questions'][i]['answer'].toLowerCase()) {
          _score++;
        }
      }
    });

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Leaderboard(name: widget.name, score: _score, totalQuizzes: widget.totalQuizzes),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.quiz['title']), backgroundColor: Colors.black),
      body: ListView.builder(
        itemCount: widget.quiz['questions'].length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(widget.quiz['questions'][index]['question'], style: TextStyle(color: Colors.white)),
            subtitle: Row(
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _answers[index] = 'Yes';
                    });
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.greenAccent),
                  child: Text('Yes'),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _answers[index] = 'No';
                    });
                  },
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.orangeAccent),
                  child: Text('No'),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _submitQuiz,
        backgroundColor: Colors.blue,
        child: Icon(Icons.check),
      ),
    );
  }
}

class Leaderboard extends StatelessWidget {
  final String name;
  final int score;
  final int totalQuizzes;

  static List<Map<String, dynamic>> leaderboard = [];

  Leaderboard({
    required this.name,
    required this.score,
    required this.totalQuizzes,
  }) {
    leaderboard.add({
      'name': name,
      'score': score,
      'timestamp': DateTime.now(),
    });
    leaderboard.sort((a, b) => b['score'].compareTo(a['score']));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Leaderboard'), backgroundColor: Colors.black),
      body: ListView.builder(
        itemCount: leaderboard.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('${leaderboard[index]['name']} - Score: ${leaderboard[index]['score']}',
                style: TextStyle(color: Colors.white)),
            subtitle: Text('Timestamp: ${leaderboard[index]['timestamp']}',
                style: TextStyle(color: Colors.greenAccent)),
          );
        },
      ),
    );
  }
}
